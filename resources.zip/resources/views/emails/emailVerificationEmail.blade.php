<h1>Email Verification Mail</h1>
  
Please verify your email with bellow link:
<p><a href="{{ route('user.verify', $token) }}">{{ route('user.verify', $token) }}</a></p>
