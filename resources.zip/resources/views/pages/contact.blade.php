@extends('pages.master')

@section('content')


<section class="ds contacts section_padding_50 ms">
				<div class="container">
					<div class="row topmargin_10 bottommargin_20">
						<div class="col-sm-4">
							<div class="teaser text-center">
								<!--<h4 class="bottommargin_20">Reception</h4>-->
								<!--Helena-->
								<br>
								<span class="highlight"><a href="mailto:info@velvetklub.com">info@velvetklub.com</a></span>
								<!-- <br> 8 (800) 456-2698 -->
							</div>
						</div>
						<div class="col-sm-4 with_border">
							<div class="teaser text-center">
								<!--<h4 class="bottommargin_20">Booking</h4>-->
								<!--James-->
								<br>
								<span class="highlight"><a href="mailto:listing@velvetklub.com">listing@velvetklub.com</a></span>
								<!-- <br> 8 (800) 456-2643 -->
							</div>
						</div>
						<div class="col-sm-4">
							<div class="teaser text-center">
								<!--<h4 class="bottommargin_20">President</h4>-->
								<!--Robert-->
								<br>
								<span class="highlight"><a href="mailto:support@velvetklub.com">support@velvetklub.com</a></span>
								<!-- <br> 8 (800) 456-5848 -->
							</div>
						</div>
					</div>
				</div>
			</section>

			<section class="ds section_padding_70">
				<div class="container">
					<div class="row">
						<div class="col-sm-offset-1 col-sm-10 col-md-offset-2 col-md-8 col-lg-offset-3 col-lg-6 text-center">
							<h2 class="big margin_0">Contact Us</h2>
							<h2 class="muellerhoff topmargin_5 bottommargin_50 highlight">Contact Form</h2>

							<form class="contact-form row" method="post" action="{{url('contact/mail/')}}">
                                @csrf
                                @method('POST')
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="name" class="sr-only">Full Name
                                            <span class="required">*</span>
                                        </label>
                                        <input type="text" aria-required="true" size="30" value="" name="name" id="name" required class="form-control with-icon" placeholder="Name" >
                                        <i class="rt-icon2-user"></i>
                                    </div>
                                    <div class="form-group">
                                        <label for="email" class="sr-only">Email address
                                            <span class="required">*</span>
                                        </label>
                                        <input type="email" aria-required="true" size="30" value="" name="email" id="email" class="form-control with-icon" placeholder="Email Address" required>
                                        <i class="rt-icon2-mail"></i>
                                    </div>
                                    <div class="form-group">
                                        <label for="phone" class="sr-only">Phone number
                                            <span class="required">*</span>
                                        </label>
                                        <input type="text" aria-required="true" size="30" value="" name="phone" id="phone" class="form-control with-icon" placeholder="Phone Number" required>
                                        <i class="rt-icon2-phone5"></i>
                                    </div>
                                    

                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="message" class="sr-only">Message</label>
                                        <textarea aria-required="true" rows="6" cols="45" name="message" id="message" class="form-control with-icon" required placeholder="Message"></textarea>
                                        <i class="rt-icon2-pen"></i>
                                    </div>

                                    <button type="submit" id="" name="contact_submit" class="theme_button color1 bottommargin_0">Send</button>
                                    <button type="reset" id="contact_form_clear" name="contact_clear" class="theme_button inverse bottommargin_0">Clear</button>
                                </div>

                            </form>
						</div>
					</div>
				</div>
			</section>

 @endsection

           