@extends('pages.master')

@section('content')


<section class="ds section_padding_70 about-content">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<article class="post format-small-image with_background">

								<div class="side-item content-padding">

									<div class="row">

										<div class="col-md-6">
											<div class="item-media entry-thumbnail">
												<img src="images/models_square/18.jpg" alt="">
											</div>
										</div>

										<div class="col-md-6">
											<div class="item-content .about-content">
												<h2 class="big topmargin_0 bottommargin_30">
													About Velvetclub
												</h2>

												<p>Lorem ipsum dolor sit amet, consetetur sadipscing esed diam nonumy eirmod tempor invidunt ut labore et dolore magna.</p>

												<p>
													At vero eos et accusam et justo duo dolores et ea rebum. Stet gubergren no sea takimata sanctus est Lorem ipsum dolor sit amet ipsumlor eut consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore et dolore magna liquyam erat.
												</p>

												<!--div class="row">
													<div class="col-sm-6">
														<ul class="list1 no-bullets">
															<li>
																<i class="highlight rt-icon2-phone5"></i>
																<span class="grey">Phone:</span>
																8 (800) 456-2698
															</li>
															<li>
																<i class="highlight rt-icon2-pen"></i>
																<span class="grey">Fax:</span>
																8 (800) 456-2698
															</li>
														</ul>
													</div>
													<div class="col-sm-6">
														<ul class="list1 no-bullets">
															<li>
																<i class="highlight rt-icon2-mail"></i>
																<span class="grey">Email:</span>
																<a href="#">
																	<em>agency@suort.com</em>
																</a>
															</li>
															<li>
																<i class="highlight rt-icon2-world"></i>
																<span class="grey">Website:</span>
																<a href="#">
																	<em>modelsagency.com</em>
																</a>
															</li>
														</ul>
													</div>
												</div-->
												<!-- <div class="page_social_icons topmargin_20">
													<a class="social-icon color-bg-icon soc-facebook" href="#" title="Facebook"></a>
													<a class="social-icon color-bg-icon soc-twitter" href="#" title="Twitter"></a>
													<a class="social-icon color-bg-icon soc-google" href="#" title="Google"></a>
													<a class="social-icon color-bg-icon soc-linkedin" href="#" title="LinkedIn"></a>
													<a class="social-icon color-bg-icon soc-pinterest" href="#" title="Pinterest"></a>
												</div> -->

											</div>
										</div>

									</div>
								</div>

							</article>
						</div>
					</div>
				</div>
			</section>

 @endsection

           