@extends('pages.master')

@section('content')
	
		
<section class="ds section_padding_top_100 section_padding_bottom_50 columns_padding_25">
				<div class="container">
					<div class="row">
						<div class="col-sm-10 col-sm-push-1">
						@if(isset($blogs))
					 	@foreach($blogs as $blog)
							<article class="vertical-item post format-standard with_background">
								<div class="item-media entry-thumbnail">
									<div class="entry-meta-corner">
										<span class="date">
											<time datetime="2016-08-01T15:05:23+00:00" class="entry-date">
												<strong>{{$blog->created_at->format('d')}}</strong>
												{{$blog->created_at->format('M')}}
											</time>
										</span>
									</div>
									@if(isset($blog->filename) && $blog->filename !='')
                                
                                	<img src="{{ asset('images/'.$blog->filename) }}" alt="">
                                
                                	@else
                                	<img src="{{ asset('images/no-image.png') }}" alt="">
									@endif
								</div>

								<div class="item-content entry-content">
									<header class="entry-header">
										<h4 class="entry-title">
										{{$blog->blog_title ? $blog->blog_title:''}}
										</h4>
									</header>
									<!-- .entry-header -->

									<p>{{$blog->descripion ? $blog->descripion:''}}</p>

								</div>
								<!-- .item-content.entry-content -->
							</article>
							@endforeach
							@endif
							<!-- .post -->
							<div class="row topmargin_60">
								<div class="col-sm-12 text-center">
									{{$blogs->links()}}
								</div>
							</div>

							

							

						</div>
						<!--eof .col-sm-8 (main content)-->


					</div>
				</div>
			</section>

			<!-- <section class="ds ms section_padding_30 page_social">
				<div class="container">
					<div class="row topmargin_20 bottommargin_10">
						<div class="col-sm-12 text-center">
							<div class="page_social_icons">
								<a class="social-icon color-bg-icon soc-facebook" href="#" title="Facebook"></a>
								<a class="social-icon color-bg-icon soc-twitter" href="#" title="Twitter"></a>
								<a class="social-icon color-bg-icon soc-google" href="#" title="Google"></a>
								<a class="social-icon color-bg-icon soc-linkedin" href="#" title="LinkedIn"></a>
								<a class="social-icon color-bg-icon soc-pinterest" href="#" title="Pinterest"></a>
							</div>
						</div>
					</div>
				</div>
			</section> -->
			

			
@endsection
